package com.jimac.rate_configuration.interfaces;

import com.jimac.rate_configuration.model.RateModel;

public interface IRateComputeListener {
    void onRateComputed(RateModel data);
    void onCancel();
}
