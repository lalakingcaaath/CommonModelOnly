package com.jimac.rate_configuration.model;

public class RateParkerModel {
    String parkerLabel;
    int parkerCode;

    public String getParkerLabel() {
        return parkerLabel;
    }

    public void setParkerLabel(String parkerLabel) {
        this.parkerLabel = parkerLabel;
    }

    public int getParkerCode() {
        return parkerCode;
    }

    public void setParkerCode(int parkerCode) {
        this.parkerCode = parkerCode;
    }
}
