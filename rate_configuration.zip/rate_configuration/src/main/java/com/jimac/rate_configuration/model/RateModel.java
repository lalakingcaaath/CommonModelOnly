package com.jimac.rate_configuration.model;

public class RateModel {
    public String vehicleCode;
    public String parkerCode;
    public String rateDesc;
    public int isFlatRate;
    public double flatRate;
    public int baseHour;
    public double baseHourRate;
    public double succeedingRatePerHour;
    public int haveGracePeriod;
    public int gracePeriod;
    public double lostTicketAmount;
    public int overrideCurrentRateWithOvernightRate;
    public String overnightStart;
    public String overnightEnd;
    public double overnightRate;
    public String action;

    public String getVehicleCode() {
        return vehicleCode;
    }

    public void setVehicleCode(String vehicleCode) {
        this.vehicleCode = vehicleCode;
    }

    public String getParkerCode() {
        return parkerCode;
    }

    public void setParkerCode(String parkerCode) {
        this.parkerCode = parkerCode;
    }

    public String getRateDesc() {
        return rateDesc;
    }

    public void setRateDesc(String rateDesc) {
        this.rateDesc = rateDesc;
    }

    public int getIsFlatRate() {
        return isFlatRate;
    }

    public void setIsFlatRate(int isFlatRate) {
        this.isFlatRate = isFlatRate;
    }

    public double getFlatRate() {
        return flatRate;
    }

    public void setFlatRate(double flatRate) {
        this.flatRate = flatRate;
    }

    public int getBaseHour() {
        return baseHour;
    }

    public void setBaseHour(int baseHour) {
        this.baseHour = baseHour;
    }

    public double getBaseHourRate() {
        return baseHourRate;
    }

    public void setBaseHourRate(double baseHourRate) {
        this.baseHourRate = baseHourRate;
    }

    public double getSucceedingRatePerHour() {
        return succeedingRatePerHour;
    }

    public void setSucceedingRatePerHour(double succeedingRatePerHour) {
        this.succeedingRatePerHour = succeedingRatePerHour;
    }

    public int getHaveGracePeriod() {
        return haveGracePeriod;
    }

    public void setHaveGracePeriod(int haveGracePeriod) {
        this.haveGracePeriod = haveGracePeriod;
    }

    public int getGracePeriod() {
        return gracePeriod;
    }

    public void setGracePeriod(int gracePeriod) {
        this.gracePeriod = gracePeriod;
    }

    public double getLostTicketAmount() {
        return lostTicketAmount;
    }

    public void setLostTicketAmount(double lostTicketAmount) {
        this.lostTicketAmount = lostTicketAmount;
    }

    public int getOverrideCurrentRateWithOvernightRate() {
        return overrideCurrentRateWithOvernightRate;
    }

    public void setOverrideCurrentRateWithOvernightRate(int overrideCurrentRateWithOvernightRate) {
        this.overrideCurrentRateWithOvernightRate = overrideCurrentRateWithOvernightRate;
    }

    public String getOvernightStart() {
        return overnightStart;
    }

    public void setOvernightStart(String overnightStart) {
        this.overnightStart = overnightStart;
    }

    public String getOvernightEnd() {
        return overnightEnd;
    }

    public void setOvernightEnd(String overnightEnd) {
        this.overnightEnd = overnightEnd;
    }

    public double getOvernightRate() {
        return overnightRate;
    }

    public void setOvernightRate(double overnightRate) {
        this.overnightRate = overnightRate;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
