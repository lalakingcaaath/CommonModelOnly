package com.jimac.rate_configuration;

import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.SwitchCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.timepicker.MaterialTimePicker;
import com.google.android.material.timepicker.TimeFormat;
import com.jimac.rate_configuration.interfaces.IRateComputeListener;
import com.jimac.rate_configuration.model.RateModel;
import com.jimac.rate_configuration.model.RateParkerModel;
import com.jimac.rate_configuration.model.RateVehicleModel;

import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class RateConfiguration extends Fragment {

    private SwitchCompat flatRateSwitch, gracePeriodSwitch, overnightSwitch, parkerTypeSwitch;
    private MaterialCardView hourlyCard, gracePeriodCard;
    private TextInputLayout flatRateTil, hoursTil, hoursRateTil,
            succeedingRateTil, gracePeriodTil, lostTicketTil,
            overnightStartTil, overnightEndTil, overnightRateTil;
    private TextInputEditText flatRateEt, hoursEt, hoursRateEt, succeedingRateEt,
            gracePeriodEt, lostTicketEt, overnightStartEt, overnightEndEt,
            overnightRateEt;

    private TextView gracePeriodTv, gracePeriodMinsTv, parkerTypeTv, overnightRateTv, flatRateTv;
    private Spinner parkerSpinner, vehicleSpinner;

    private List<RateParkerModel> parkerModelList;
    private List<RateVehicleModel> vehicleModelList;

    private MaterialButton btnSave;
    private RateModel rateModel;
    private IRateComputeListener rateCallback;


    public static RateConfiguration newInstance(RateModel rateModel,
                                                List<RateParkerModel> parkerModelList,
                                                List<RateVehicleModel> vehicleModelList) {
        RateConfiguration fragment = new RateConfiguration();
        fragment.rateModel = rateModel != null ? rateModel : new RateModel();
        fragment.parkerModelList = parkerModelList;
        fragment.vehicleModelList = vehicleModelList;
        return fragment;
    }

    public RateConfiguration() {
    }

    public void setOnRateComputeListener(IRateComputeListener listener) {
        this.rateCallback = listener;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_rate_configuration, container, false);
        initView(view);
        afterInit();
        setEditText();
        return view;
    }

    private void initView(View view) {
        hourlyCard = view.findViewById(R.id.hourly_card);
        gracePeriodCard = view.findViewById(R.id.grace_period_card);

        flatRateSwitch = view.findViewById(R.id.switch_flat_rate);
        gracePeriodSwitch = view.findViewById(R.id.switch_grace_period);
        overnightSwitch = view.findViewById(R.id.switch_overnight);
        parkerTypeSwitch = view.findViewById(R.id.switch_parker_type);

        flatRateTv = view.findViewById(R.id.flat_rate_tv);
        flatRateTil = view.findViewById(R.id.flat_rate_til);
        flatRateEt = view.findViewById(R.id.flat_rate_et);

        hoursTil = view.findViewById(R.id.hours_til);
        hoursEt = view.findViewById(R.id.hours_et);
        hoursRateTil = view.findViewById(R.id.hours_rate_til);
        hoursRateEt = view.findViewById(R.id.hours_rate_et);
        succeedingRateTil = view.findViewById(R.id.succeeding_rate_til);
        succeedingRateEt = view.findViewById(R.id.succeeding_rate_et);

        gracePeriodTv = view.findViewById(R.id.grace_period_tv);
        gracePeriodTil = view.findViewById(R.id.grace_period_til);
        gracePeriodEt = view.findViewById(R.id.grace_period_et);
        gracePeriodMinsTv = view.findViewById(R.id.grace_period_mins_tv);

        lostTicketTil = view.findViewById(R.id.lost_ticket_til);
        lostTicketEt = view.findViewById(R.id.lost_ticket_et);

        overnightStartTil = view.findViewById(R.id.overnight_start_til);
        overnightStartEt = view.findViewById(R.id.overnight_start_et);
        overnightEndTil = view.findViewById(R.id.overnight_end_til);
        overnightEndEt = view.findViewById(R.id.overnight_end_et);
        overnightRateTv = view.findViewById(R.id.overnight_rate_tv);
        overnightRateTil = view.findViewById(R.id.overnight_rate_til);
        overnightRateEt = view.findViewById(R.id.overnight_rate_et);

        parkerTypeTv = view.findViewById(R.id.parker_type_tv);
        parkerSpinner = view.findViewById(R.id.parker_spinner);
        vehicleSpinner = view.findViewById(R.id.vehicle_spinner);

        btnSave = view.findViewById(R.id.btn_save);
    }

    private void afterInit() {
        setupSpinners();

        parkerTypeSwitch.setChecked(true);
        parkerTypeTv.setVisibility(View.VISIBLE);
        parkerSpinner.setVisibility(View.VISIBLE);

        applyFlatRateState(flatRateSwitch.isChecked());
        applyGracePeriodState(gracePeriodSwitch.isChecked());

        parkerTypeSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                applyParkerTypeState(isChecked));

        btnSave.setOnClickListener(v -> {
            if (validateFields()) {
                computeParkingRate();

                getParentFragmentManager().popBackStack();
            }
        });

        overnightStartEt.setOnClickListener(v -> showTimePicker(overnightStartEt, true));
        overnightEndEt.setOnClickListener(v -> showTimePicker(overnightEndEt, false));
    }

    private void setupSpinners() {
        if (parkerModelList != null && !parkerModelList.isEmpty()) {
            List<String> parkerLabels = new ArrayList<>();
            for (RateParkerModel model : parkerModelList) {
                parkerLabels.add(model.getParkerLabel());
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    requireContext(),
                    android.R.layout.simple_spinner_item,
                    parkerLabels
            );
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            parkerSpinner.setAdapter(adapter);
        }

        if (vehicleModelList != null && !vehicleModelList.isEmpty()) {
            List<String> vehicleLabels = new ArrayList<>();
            for (RateVehicleModel model : vehicleModelList) {
                vehicleLabels.add(model.getVehicleLabel());
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    requireContext(),
                    android.R.layout.simple_spinner_item,
                    vehicleLabels
            );
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            vehicleSpinner.setAdapter(adapter);
        }

        int vehicleSelectedIndex = 0;

        if ("view".equals(rateModel.getAction()) && rateModel.getVehicleCode() != null) {
            for (int i = 0; i < vehicleModelList.size(); i++) {
                if (String.valueOf(vehicleModelList.get(i).getVehicleCode()).equals(rateModel.getVehicleCode())) {
                    vehicleSelectedIndex = i;
                    break;
                }
            }
        }
        vehicleSpinner.setSelection(vehicleSelectedIndex);
    }

    private void attachSwitchListeners() {
        flatRateSwitch.setOnCheckedChangeListener((b, isChecked) -> applyFlatRateState(isChecked));
        gracePeriodSwitch.setOnCheckedChangeListener((b, isChecked) -> applyGracePeriodState(isChecked));
        overnightSwitch.setOnCheckedChangeListener((b, isChecked) -> applyOvernightState(isChecked));
    }

    private void detachSwitchListeners() {
        flatRateSwitch.setOnCheckedChangeListener(null);
        gracePeriodSwitch.setOnCheckedChangeListener(null);
        overnightSwitch.setOnCheckedChangeListener(null);
    }

    private void applyFlatRateState(boolean isEnabled) {
        if (isEnabled) {
            flatRateTv.setVisibility(View.VISIBLE);
            flatRateTil.setVisibility(View.VISIBLE);
            hourlyCard.setVisibility(View.GONE);
            hoursTil.setError(null);
            hoursRateTil.setError(null);
            succeedingRateTil.setError(null);
        } else {
            flatRateTv.setVisibility(View.GONE);
            flatRateTil.setVisibility(View.GONE);
            flatRateTil.setError(null);
            hourlyCard.setVisibility(View.VISIBLE);
        }
    }

    private void applyGracePeriodState(boolean isEnabled) {
        int visibility = isEnabled ? View.VISIBLE : View.GONE;
        gracePeriodTv.setVisibility(visibility);
        gracePeriodTil.setVisibility(visibility);
        gracePeriodMinsTv.setVisibility(visibility);
        if (!isEnabled) gracePeriodTil.setError(null);
    }

    private void applyOvernightState(boolean isEnabled) {
        if (isEnabled) {
            flatRateTv.setVisibility(View.GONE);
            flatRateTil.setVisibility(View.GONE);
            hourlyCard.setVisibility(View.GONE);
            gracePeriodCard.setVisibility(View.GONE);
        } else {
            applyFlatRateState(flatRateSwitch.isChecked());
            applyGracePeriodState(gracePeriodSwitch.isChecked());
            gracePeriodCard.setVisibility(View.VISIBLE);
        }
    }

    private void applyParkerTypeState(boolean isEnabled) {
        int visibility = isEnabled ? View.VISIBLE : View.GONE;
        parkerTypeTv.setVisibility(visibility);
        parkerSpinner.setVisibility(visibility);
    }

    private boolean validateFields() {
        boolean isValid = true;

        if (!overnightSwitch.isChecked()) {
            if (flatRateSwitch.isChecked()) {
                isValid = validateTil(flatRateTil, flatRateEt) && isValid;
            } else {
                isValid = validateTil(hoursTil, hoursEt) && isValid;
                isValid = validateTil(hoursRateTil, hoursRateEt) && isValid;
                isValid = validateTil(succeedingRateTil, succeedingRateEt) && isValid;
            }

            if (gracePeriodSwitch.isChecked()) {
                isValid = validateTil(gracePeriodTil, gracePeriodEt) && isValid;
            }
        }

        isValid = validateTil(overnightStartTil, overnightStartEt) && isValid;
        isValid = validateTil(overnightEndTil, overnightEndEt) && isValid;
        isValid = validateTil(overnightRateTil, overnightRateEt) && isValid;

        return isValid;
    }

    private boolean validateTil(TextInputLayout til, TextInputEditText et) {
        if (et == null || et.getText() == null || et.getText().toString().trim().isEmpty()) {
            til.setError("This field is required");
            return false;
        } else {
            til.setError(null);
            return true;
        }
    }

    private void computeParkingRate() {
        boolean isFlatRate = flatRateSwitch.isChecked();
        boolean isOvernightEnabled = overnightSwitch.isChecked();
        boolean isGracePeriodEnabled = gracePeriodSwitch.isChecked();
        boolean isParkerTypeEnabled = parkerTypeSwitch.isChecked();

        int isFlatRateInt = isFlatRate ? 1 : 0;
        int haveGracePeriod = isGracePeriodEnabled ? 1 : 0;
        int overrideCurrentRateWithOvernightRate = isOvernightEnabled ? 1 : 0;

        // Get code from model list using spinner position
        int vehiclePosition = vehicleSpinner.getSelectedItemPosition();
        int parkerPosition = parkerSpinner.getSelectedItemPosition();

        String vehicleCode = (vehicleModelList != null && vehiclePosition >= 0 && vehiclePosition < vehicleModelList.size())
                ? String.valueOf(vehicleModelList.get(vehiclePosition).getVehicleCode())
                : "0";

        String parkerCode = (isParkerTypeEnabled && parkerModelList != null && parkerPosition >= 0 && parkerPosition < parkerModelList.size())
                ? String.valueOf(parkerModelList.get(parkerPosition).getParkerCode())
                : "0";

        String lostTicketStr = lostTicketEt.getText().toString().trim();
        double lostTicketAmount = lostTicketStr.isEmpty() ? 0.0 : Double.parseDouble(lostTicketStr);

        String parkerLabel = (parkerModelList != null && parkerPosition >= 0 && parkerPosition < parkerModelList.size())
                ? parkerModelList.get(parkerPosition).getParkerLabel()
                : "";

        String vehicleLabel = (vehicleModelList != null && vehiclePosition >= 0 && vehiclePosition < vehicleModelList.size())
                ? vehicleModelList.get(vehiclePosition).getVehicleLabel()
                : "";

        String rateDescStr = vehicleLabel + "-" + parkerLabel;

        double flatRate = 0.0;
        int baseHour = 0;
        double baseHourRate = 0.0;
        double succeedingRatePerHour = 0.0;
        int gracePeriod = 0;

        if (!isOvernightEnabled) {
            if (isFlatRate) {
                flatRate = Double.parseDouble(flatRateEt.getText().toString().trim());
            } else {
                baseHour = Integer.parseInt(hoursEt.getText().toString().trim());
                baseHourRate = Double.parseDouble(hoursRateEt.getText().toString().trim());
                succeedingRatePerHour = Double.parseDouble(succeedingRateEt.getText().toString().trim());

                if (isGracePeriodEnabled) {
                    gracePeriod = Integer.parseInt(gracePeriodEt.getText().toString().trim());
                }
            }
        }

        String overnightStart = convertTo24Hour(overnightStartEt.getText().toString().trim());
        String overnightEnd = convertTo24Hour(overnightEndEt.getText().toString().trim());
        double overnightRate = Double.parseDouble(overnightRateEt.getText().toString().trim());

        RateModel data = new RateModel();
        data.vehicleCode = vehicleCode;
        data.parkerCode = parkerCode;
        data.rateDesc = rateDescStr;
        data.isFlatRate = isFlatRateInt;
        data.flatRate = flatRate;
        data.baseHour = baseHour;
        data.baseHourRate = baseHourRate;
        data.succeedingRatePerHour = succeedingRatePerHour;
        data.haveGracePeriod = haveGracePeriod;
        data.gracePeriod = gracePeriod;
        data.lostTicketAmount = lostTicketAmount;
        data.overrideCurrentRateWithOvernightRate = overrideCurrentRateWithOvernightRate;
        data.overnightStart = overnightStart;
        data.overnightEnd = overnightEnd;
        data.overnightRate = overnightRate;

        if (this.rateModel != null) {
            data.setAction(this.rateModel.getAction());
        }

        if (rateCallback != null) {
            rateCallback.onRateComputed(data);
        }

        Toast.makeText(getContext(), "Parking rate computed", Toast.LENGTH_SHORT).show();
    }

    private void setEditText() {
        if (this.rateModel == null) return;

        detachSwitchListeners();

        flatRateSwitch.setChecked(rateModel.isFlatRate == 1);
        gracePeriodSwitch.setChecked(rateModel.haveGracePeriod == 1);
        overnightSwitch.setChecked(rateModel.overrideCurrentRateWithOvernightRate == 1);

        applyFlatRateState(flatRateSwitch.isChecked());
        applyGracePeriodState(gracePeriodSwitch.isChecked());
        applyOvernightState(overnightSwitch.isChecked());

        if (rateModel.flatRate > 0) flatRateEt.setText(String.valueOf(rateModel.flatRate));
        if (rateModel.baseHour > 0) hoursEt.setText(String.valueOf(rateModel.baseHour));
        if (rateModel.baseHourRate > 0) hoursRateEt.setText(String.valueOf(rateModel.baseHourRate));
        if (rateModel.succeedingRatePerHour > 0) succeedingRateEt.setText(String.valueOf(rateModel.succeedingRatePerHour));
        if (rateModel.gracePeriod > 0) gracePeriodEt.setText(String.valueOf(rateModel.gracePeriod));
        if (rateModel.lostTicketAmount > 0) lostTicketEt.setText(String.valueOf(rateModel.lostTicketAmount));
        if (rateModel.overnightStart != null) overnightStartEt.setText(formatToDisplayTime(rateModel.overnightStart));
        if (rateModel.overnightEnd != null) overnightEndEt.setText(formatToDisplayTime(rateModel.overnightEnd));
        if (rateModel.overnightRate > 0) overnightRateEt.setText(String.valueOf(rateModel.overnightRate));

        // Restore spinner by matching code from model list
        if (rateModel.vehicleCode != null && vehicleModelList != null) {
            int code = Integer.parseInt(rateModel.vehicleCode);
            for (int i = 0; i < vehicleModelList.size(); i++) {
                if (vehicleModelList.get(i).getVehicleCode() == code) {
                    vehicleSpinner.setSelection(i);
                    break;
                }
            }
        }

        if (rateModel.parkerCode != null && !rateModel.parkerCode.equals("0") && parkerModelList != null) {
            int code = Integer.parseInt(rateModel.parkerCode);
            for (int i = 0; i < parkerModelList.size(); i++) {
                if (parkerModelList.get(i).getParkerCode() == code) {
                    parkerSpinner.setSelection(i);
                    break;
                }
            }
        }

        attachSwitchListeners();

        String action = rateModel.getAction();
        if (action == null) {
            action = "add";
            rateModel.setAction("add");
        }

        switch (action.toLowerCase()) {
            case "add":
                actionAdd();
                break;
            case "edit":
                actionEdit();
                break;
            case "view":
                actionView();
                break;
            default:
                Toast.makeText(getContext(), "Action should only be add, edit or view!", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private void actionAdd() {
        detachSwitchListeners();

        flatRateEt.setText("");
        hoursEt.setText("");
        hoursRateEt.setText("");
        succeedingRateEt.setText("");
        gracePeriodEt.setText("");
        lostTicketEt.setText("");
        overnightStartEt.setText("");
        overnightEndEt.setText("");
        overnightRateEt.setText("");

        flatRateSwitch.setChecked(false);
        gracePeriodSwitch.setChecked(false);
        overnightSwitch.setChecked(false);

        applyFlatRateState(false);
        applyGracePeriodState(false);
        applyOvernightState(false);

        attachSwitchListeners();
    }

    private void actionEdit() {
        flatRateEt.setEnabled(true);
        hoursEt.setEnabled(true);
        hoursRateEt.setEnabled(true);
        succeedingRateEt.setEnabled(true);
        gracePeriodEt.setEnabled(true);
        lostTicketEt.setEnabled(true);
        overnightStartEt.setEnabled(true);
        overnightEndEt.setEnabled(true);
        overnightRateEt.setEnabled(true);

        flatRateSwitch.setEnabled(true);
        gracePeriodSwitch.setEnabled(true);
        overnightSwitch.setEnabled(true);
        parkerTypeSwitch.setEnabled(true);

        parkerSpinner.setEnabled(true);
        vehicleSpinner.setEnabled(true);

        btnSave.setEnabled(true);
        btnSave.setVisibility(View.VISIBLE);
    }

    private void actionView() {
        flatRateEt.setEnabled(false);
        hoursEt.setEnabled(false);
        hoursRateEt.setEnabled(false);
        succeedingRateEt.setEnabled(false);
        gracePeriodEt.setEnabled(false);
        lostTicketEt.setEnabled(false);
        overnightStartEt.setEnabled(false);
        overnightEndEt.setEnabled(false);
        overnightRateEt.setEnabled(false);

        flatRateSwitch.setEnabled(false);
        gracePeriodSwitch.setEnabled(false);
        overnightSwitch.setEnabled(false);
        parkerTypeSwitch.setEnabled(false);

        parkerSpinner.setEnabled(false);
        vehicleSpinner.setEnabled(false);

        btnSave.setEnabled(false);
        btnSave.setVisibility(View.GONE);
    }

    private void showTimePicker(TextInputEditText targetEt, boolean isStart) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        String existing = targetEt.getText() != null ? targetEt.getText().toString().trim() : "";
        if (!existing.isEmpty()) {
            try {
                SimpleDateFormat displayFormat = new SimpleDateFormat("hh:mm a", Locale.US);
                Calendar parsed = Calendar.getInstance();
                parsed.setTime(displayFormat.parse(existing));
                hour = parsed.get(Calendar.HOUR_OF_DAY);
                minute = parsed.get(Calendar.MINUTE);
            } catch (Exception ignored) {
                // fall back to current time
            }
        }

        MaterialTimePicker picker = new MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setHour(hour)
                .setMinute(minute)
                .setTitleText(isStart ? "Select Start Time" : "Select End Time")
                .build();

        picker.addOnPositiveButtonClickListener(v -> {
            Calendar selected = Calendar.getInstance();
            selected.set(Calendar.HOUR_OF_DAY, picker.getHour());
            selected.set(Calendar.MINUTE, picker.getMinute());

            SimpleDateFormat displayFormat = new SimpleDateFormat("hh:mm a", Locale.US);
            targetEt.setText(displayFormat.format(selected.getTime()));

            TextInputLayout til = isStart ? overnightStartTil : overnightEndTil;
            til.setError(null);
        });

        picker.show(getParentFragmentManager(), isStart ? "start_time_picker" : "end_time_picker");
    }

    // Converts a stored 24-hour "HH:mm" string to 12-hour display, e.g. "22:30" -> "10:30 PM"
    private String formatToDisplayTime(String rawTime) {
        if (rawTime == null || rawTime.trim().isEmpty()) return "";
        try {
            SimpleDateFormat sourceFormat = new SimpleDateFormat("HH:mm", Locale.US);
            SimpleDateFormat displayFormat = new SimpleDateFormat("hh:mm a", Locale.US);
            return displayFormat.format(sourceFormat.parse(rawTime.trim()));
        } catch (Exception e) {
            return rawTime; // already formatted or unrecognized, show as-is
        }
    }

    // Converts the picker's 12-hour display string back to 24-hour "HH:mm" for storage
    private String convertTo24Hour(String displayTime) {
        if (displayTime == null || displayTime.trim().isEmpty()) return "";
        try {
            SimpleDateFormat displayFormat = new SimpleDateFormat("hh:mm a", Locale.US);
            SimpleDateFormat storageFormat = new SimpleDateFormat("HH:mm", Locale.US);
            return storageFormat.format(displayFormat.parse(displayTime.trim()));
        } catch (Exception e) {
            return displayTime;
        }
    }
}