package com.jimac.rate_configuration.model;

public class RateVehicleModel {

    String vehicleLabel;
    int vehicleCode;

    public String getVehicleLabel() {
        return vehicleLabel;
    }

    public void setVehicleLabel(String vehicleLabel) {
        this.vehicleLabel = vehicleLabel;
    }

    public int getVehicleCode() {
        return vehicleCode;
    }

    public void setVehicleCode(int vehicleCode) {
        this.vehicleCode = vehicleCode;
    }
}
