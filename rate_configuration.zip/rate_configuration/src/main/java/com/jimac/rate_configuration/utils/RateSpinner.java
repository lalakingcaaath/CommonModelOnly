package com.jimac.rate_configuration.utils;

public class RateSpinner {

    public final String label;
    public final int code;

    public RateSpinner(String label, int code) {
        this.label = label;
        this.code = code;
    }

    @Override
    public String toString() {
        return label;
    }
}
